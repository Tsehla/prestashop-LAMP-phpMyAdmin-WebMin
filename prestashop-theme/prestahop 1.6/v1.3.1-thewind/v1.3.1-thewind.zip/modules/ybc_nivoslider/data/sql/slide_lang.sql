INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','Women’s Fashion','','New arrivals 2016','Purchase now','http://www.prestashop.com&utm_campaign=back-office-EN&utm_content=download','home-3-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('5','_ID_LANG_','New Styles','','Men\'s Fashion & Clothing','Purchase now','#','c0e8a73a28659034fbd49dc1de493ef5cb1b8669_home-1-slider-b.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','New Arrivals','','Find out what\'s new','Purchase now','#','a3d66970cfa3f7304b615cadfbde30b3901ffdba_home-1-slider-c.jpg');


