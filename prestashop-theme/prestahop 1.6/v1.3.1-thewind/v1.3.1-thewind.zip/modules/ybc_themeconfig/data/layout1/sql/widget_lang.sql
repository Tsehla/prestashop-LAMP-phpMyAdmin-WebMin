INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('2','_ID_LANG_','Hot deals','<p>Discover our biggest offers</p>
<p><a href=\"#\" class=\"btn-light\">Shop Online</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('3','_ID_LANG_','Men\'s watches','<h3>40% Off</h3>
<p><a href=\"#\" class=\"btn button\">Shop Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('4','_ID_LANG_','Look book','<h3>25% Off</h3>
<p><a href=\"#\" class=\"btn button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','banner 1','<div class=\"block_banner_home\">
<h4>Hot deals for summer</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco nisi ut aliquip ex ea commodo consequat</p>
<ul class=\"ybc_list_dots\">
<li><span class=\"text_dots\">Faded short sleeves t-shirt</span><span class=\"text_price\">$199</span></li>
<li><span class=\"text_dots\">Faded short </span><span class=\"text_price\">$199</span></li>
<li><span class=\"text_dots\">Faded short sleeves t-shirt</span><span class=\"text_price\">$199</span></li>
<li><span class=\"text_dots\">Faded short sleeves t-shirt</span><span class=\"text_price\">$199</span></li>
<li><span class=\"text_dots\">Faded short sleeves t-shirt short sleeves t-shirt</span><span class=\"text_price\">$199</span></li>
<li><span class=\"text_dots\">Faded short sleeves t-shirt</span><span class=\"text_price\">$199</span></li>
<li><span class=\"text_dots\">Faded short sleeves t-shirt</span><span class=\"text_price\">$199</span></li>
</ul>
<p><button>PURCHARSE NOW</button> <span class=\"other_font\">Products of Love</span></p>
</div>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('15','_ID_LANG_','Men\'s vest','<h3>30% Off</h3>
<p><a href=\"#\" class=\"btn button\">Shop Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('16','_ID_LANG_','Women\'s  hand bag','<h3>10% Off</h3>
<p><a href=\"#\" class=\"btn button\">Shop Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('17','_ID_LANG_','New arriavals','<p>Hotest items of the summer has come!</p>
<p><a class=\"btn-light\" href=\"#\">Purchase now</a></p>');


