INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('1','_ID_LANG_','Home');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('4','_ID_LANG_','Accessories');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('5','_ID_LANG_','Contact');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('7','_ID_LANG_','Blog');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('11','_ID_LANG_','Women\'s');


INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('8','_ID_LANG_','Clothing','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('9','_ID_LANG_','Casual Jean','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('10','_ID_LANG_','Best Sellers','','');


INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('5','_ID_LANG_','Column 6/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('7','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('8','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('9','_ID_LANG_','Full width','');


