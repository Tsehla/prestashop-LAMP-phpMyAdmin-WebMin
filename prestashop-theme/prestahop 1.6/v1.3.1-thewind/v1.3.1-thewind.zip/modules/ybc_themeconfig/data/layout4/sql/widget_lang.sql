INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('2','_ID_LANG_','Hot deals','<p>Discover our biggest offers</p>
<p><a href=\"#\" class=\"btn-light\">Shop Online</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('3','_ID_LANG_','Men\'s watches','<h3>40% Off</h3>
<p><a href=\"#\" class=\"btn button\">Shop Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('4','_ID_LANG_','Look book','<h3>25% Off</h3>
<p><a href=\"#\" class=\"btn button\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('15','_ID_LANG_','Men\'s vest','<h3>30% Off</h3>
<p><a href=\"#\" class=\"btn button\">Shop Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('16','_ID_LANG_','Women\'s  hand bag','<h3>10% Off</h3>
<p><a href=\"#\" class=\"btn button\">Shop Now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('17','_ID_LANG_','New arriavals','<p>Hotest items of the summer has come!</p>
<p><a class=\"btn-light\" href=\"#\">Purchase now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('30','_ID_LANG_','discovery','<h4>A Comprehensive Guide to the Fall 2016 Fashion Trends</h4>
<h4>​From statement furs to velvet everything, this is what\'s trending for fall 2016​​.</h4>
<p><a href=\"#\" class=\"button_light\">Discover now</a></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('31','_ID_LANG_','About Us','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi</p>');


