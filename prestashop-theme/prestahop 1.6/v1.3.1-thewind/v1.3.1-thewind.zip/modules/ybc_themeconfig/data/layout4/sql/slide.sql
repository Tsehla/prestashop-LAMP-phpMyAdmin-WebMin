INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('4','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('11','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('12','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('4','9','1','random','10%','','10%','type1','left','center','60%','c1_cl_w c2_cl_w','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('11','10','1','random','15%','10%','10%','type2','left','center','40%','c2_fs_50 c2_cl_w c1_cl_w','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('12','11','1','random','10%','10%','10%','type3','right','center','50%','c1_cl_red c2_fs_50','#');


