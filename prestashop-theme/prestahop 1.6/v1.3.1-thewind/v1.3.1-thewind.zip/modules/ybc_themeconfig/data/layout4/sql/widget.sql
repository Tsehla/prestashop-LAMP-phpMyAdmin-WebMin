INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('2','displayTopColumn','1','1','1','1','top-1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('3','displayTopColumn','1','1','1','1','top-2.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('4','displayTopColumn','1','1','1','1','top-3.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('15','displayTopColumn','1','1','1','1','top-4.jpg','','','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('16','displayTopColumn','1','1','1','1','top-5.jpg','','','5');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('17','displayTopColumn','1','1','1','1','top-6.jpg','','','6');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('30','displayHome','0','0','1','1','banner-home-5.jpg','','','7');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('31','displayFooter','1','1','1','1','','','#','1');


