INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','Women’s hand bags','','70% off all items','Purchase now','#','3e2e0bc0d519cb688d4205967edd08a74fd71d4d_slider-4.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('11','_ID_LANG_','Accessories','','for Women','Purchase now','#','028af27c4289e39e049875b24818bf06b8ad8189_home-4-slide-b.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('12','_ID_LANG_','Women’s dress','','New arrivals','Purchase now','#','084f53e46fa9ffc4169a60fef37711ae1452594b_home-4-slider-a.jpg');


