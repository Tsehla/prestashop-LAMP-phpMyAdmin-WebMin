INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('1','HOME','','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('4','CUSTOM','#','0','0','0','LEFT','25','','','','','','#4a4a4a','title','1','bottom','','','','1','','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('5','CONTACT','','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','','1','8');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('7','CUSTOM','http://theme.yourbestcode.com/thewind/blog','0','0','0','FULL','100','#333333','#777777','','#FF564B','#DDDDDD','#FFFFFF','title','1','bottom','','','ybc_new','1','','1','7');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('11','CUSTOM','#','0','0','0','FULL','300','','','','','','#4a4a4a','title','1','bottom','','','','1','','0','4');


INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('8','7','HTML','a:6:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:4:{i:0;s:1:\"3\";i:1;s:1:\"7\";i:2;s:1:\"9\";i:3;s:2:\"10\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}s:4:\"HTML\";s:324:\"PHVsPg0KPGxpPjxhIGhyZWY9IiMiPkJsb3VzZXMgVG9wczwvYT48L2xpPg0KPGxpPjxhIGhyZWY9IiMiIGNsYXNzPSJ5YmMtbW0taXRlbS1saW5rIj5DYXN1YWwgRHJlc3NlczwvYT48L2xpPg0KPGxpPjxhIGhyZWY9IiMiIGNsYXNzPSJ5YmMtbW0taXRlbS1saW5rIj5FdmVuaW5nIERyZXNzZXM8L2E+PC9saT4NCjxsaT48YSBocmVmPSIjIiBjbGFzcz0ieWJjLW1tLWl0ZW0tbGluayI+VC1zaGlydHM8L2E+PC9saT4NCjwvdWw+\";}','1','1','1','','1','','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('9','7','HTML','a:6:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:4:{i:0;s:1:\"3\";i:1;s:1:\"7\";i:2;s:1:\"9\";i:3;s:2:\"10\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}s:4:\"HTML\";s:324:\"PHVsPg0KPGxpPjxhIGhyZWY9IiMiPkJsb3VzZXMgVG9wczwvYT48L2xpPg0KPGxpPjxhIGhyZWY9IiMiIGNsYXNzPSJ5YmMtbW0taXRlbS1saW5rIj5DYXN1YWwgRHJlc3NlczwvYT48L2xpPg0KPGxpPjxhIGhyZWY9IiMiIGNsYXNzPSJ5YmMtbW0taXRlbS1saW5rIj5FdmVuaW5nIERyZXNzZXM8L2E+PC9saT4NCjxsaT48YSBocmVmPSIjIiBjbGFzcz0ieWJjLW1tLWl0ZW0tbGluayI+VC1zaGlydHM8L2E+PC9saT4NCjwvdWw+\";}','1','1','1','','1','','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('10','8','HTML','a:6:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:4:{i:0;s:1:\"3\";i:1;s:1:\"7\";i:2;s:1:\"9\";i:3;s:2:\"10\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}s:4:\"HTML\";s:324:\"PHVsPg0KPGxpPjxhIGhyZWY9IiMiPkJsb3VzZXMgVG9wczwvYT48L2xpPg0KPGxpPjxhIGhyZWY9IiMiIGNsYXNzPSJ5YmMtbW0taXRlbS1saW5rIj5DYXN1YWwgRHJlc3NlczwvYT48L2xpPg0KPGxpPjxhIGhyZWY9IiMiIGNsYXNzPSJ5YmMtbW0taXRlbS1saW5rIj5FdmVuaW5nIERyZXNzZXM8L2E+PC9saT4NCjxsaT48YSBocmVmPSIjIiBjbGFzcz0ieWJjLW1tLWl0ZW0tbGluayI+VC1zaGlydHM8L2E+PC9saT4NCjwvdWw+\";}','1','1','1','','1','','','1');


INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('5','3','1','','0','0','','6_12','men-fashion4.jpg','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('7','3','1','','0','0','','3_12','','0','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('8','3','1','','0','0','','3_12','','0','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('9','4','1','','0','0','','12_12','','0','1');


