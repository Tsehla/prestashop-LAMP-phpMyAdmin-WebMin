INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','Summer Collection','','New arrivals 2016','Purchase now','http://www.prestashop.com&utm_campaign=back-office-EN&utm_content=download','b122222098ad9d0958fbb36816ab2304e4dd5d78_home-2-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','Men’s Fashion','','Latest Fashion Styles','Purchase now','#','e23a5327bb00bdaeb8c4abc35324b7273d7b1ae3_home-2-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','Summer Collection','','Trends and looks','Purchase now','#','ab884f431aff623ba87315bd1634e4034e8015d3_home-2-slide-c.jpg');


