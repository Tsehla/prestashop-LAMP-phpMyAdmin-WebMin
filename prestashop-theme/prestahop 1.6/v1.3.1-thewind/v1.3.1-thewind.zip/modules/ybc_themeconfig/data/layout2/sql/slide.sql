INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','7','1','random','16%','10%','10%','type1','center','center','60%','c2_fs_60 c2_cl_w c2_ls_10 c1_cl_w c1_fs_40','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','6','1','random','16%','10%','10%','type2','right','center','50%','c1_cl_w c2_cl_w c2_ls_5 c2_fs_40','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','8','1','random','15%','10%','10%','type1','left','center','40%','c1_cl_w c2_cl_w c2_ls_5 bt_bg_blue','#');


