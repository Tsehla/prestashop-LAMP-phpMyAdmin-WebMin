INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('18','_ID_LANG_','FREE AND FAST DELIVERY','<h4>FREE AND FAST DELIVERY</h4>
<p>For all order over $200 before 1.1.2017</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('19','_ID_LANG_','MONEY BACK GUARANTEE','<h4>MONEY BACK GUARANTEE</h4>
<p>We offer a money back guarantee for all products</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('20','_ID_LANG_','FREE RETURN AND EXCHANGE','<h4>FREE RETURN AND EXCHANGE</h4>
<p>All orders that come within the United States</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('21','_ID_LANG_','sale off','<h3>40%</h3>
<p>Men’s items only</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('22','_ID_LANG_','Women’s  hand bag','<h4 class=\"font_other\">Women’s</h4>
<h4>hand bag</h4>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('23','_ID_LANG_','Women’s  fahsion Boots','<h4 class=\"font_other\">Women’s</h4>
<h4>fahsion Boots</h4>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('24','_ID_LANG_','Collection 2016','<h4 class=\"font_other\">Jewelry</h4>
<h4>Collection 2016</h4>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('25','_ID_LANG_','testimonial','<div class=\"testimonial_item\">
<h4 class=\"other_font\">From customers</h4>
<p><img src=\"http://demo.yourbestcode.com/sang/thewind/img/cms/author-1.png\" alt=\"\" width=\"143\" height=\"143\" /></p>
<h4 class=\"other_font\">-- Diamond Gate --</h4>
<div class=\"content_testimonial\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</div>
</div>
<div class=\"testimonial_item\">
<h4 class=\"other_font\">From customers</h4>
<p><img src=\"http://demo.yourbestcode.com/sang/thewind/img/cms/author-1.png\" alt=\"\" width=\"143\" height=\"143\" /></p>
<h4 class=\"other_font\">-- Sang Su --</h4>
<div class=\"content_testimonial\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</div>
</div>
<div class=\"testimonial_item\">
<h4 class=\"other_font\">From customers</h4>
<p><img src=\"http://demo.yourbestcode.com/sang/thewind/img/cms/author-1.png\" alt=\"\" width=\"143\" height=\"143\" /></p>
<h4 class=\"other_font\">-- Jully Smile --</h4>
<div class=\"content_testimonial\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet.</div>
</div>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('31','_ID_LANG_','About Us','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi</p>');


