INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('18','displayTopColumn','1','0','1','1','','','#','7');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('19','displayTopColumn','1','0','1','1','','','#','8');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('20','displayTopColumn','1','0','1','1','','','#','9');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('21','ybcCustom1','1','1','1','1','top-8.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('22','ybcCustom1','1','0','1','1','top-9.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('23','ybcCustom1','1','0','1','1','top-10.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('24','ybcCustom1','1','0','1','1','top-11.jpg','','#','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('25','displayHome','1','0','1','1','testimonia.jpg','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('31','displayFooter','1','1','1','1','','','#','1');


