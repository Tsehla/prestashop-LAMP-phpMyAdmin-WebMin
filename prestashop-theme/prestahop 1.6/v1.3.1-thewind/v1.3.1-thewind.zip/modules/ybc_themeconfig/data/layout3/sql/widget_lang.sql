INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('18','_ID_LANG_','FREE AND FAST DELIVERY','<h4>FREE AND FAST DELIVERY</h4>
<p>For all order over $200 before 1.1.2017</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('19','_ID_LANG_','MONEY BACK GUARANTEE','<h4>MONEY BACK GUARANTEE</h4>
<p>We offer a money back guarantee for all products</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('20','_ID_LANG_','FREE RETURN AND EXCHANGE','<h4>FREE RETURN AND EXCHANGE</h4>
<p>All orders that come within the United States</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('21','_ID_LANG_','sale off','<h3>40%</h3>
<p>Men’s items only</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('22','_ID_LANG_','Women’s  hand bag','<h4 class=\"font_other\">Women’s</h4>
<h4>hand bag</h4>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('23','_ID_LANG_','Women’s  fahsion Boots','<h4 class=\"font_other\">Women’s</h4>
<h4>fahsion Boots</h4>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('24','_ID_LANG_','Collection 2016','<h4 class=\"font_other\">Jewelry</h4>
<h4>Collection 2016</h4>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('26','_ID_LANG_','lookbook','<h5>the best products</h5>
<h4><span>LOOK</span> BOOK</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. tellus sed augue semper porta. Mauris massa</p>
<p><button>Discover</button></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('27','_ID_LANG_','for children','<h4>For children</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. tellus sed augue semper porta. Mauris massa</p>
<p><button>Learn more</button></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('28','_ID_LANG_','men collection','<h4>Men’s fashion</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. tellus sed augue semper porta. Mauris massa</p>
<p><button>Learn more</button></p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('29','_ID_LANG_','summersale','<h5>sALE OFF ALL PRODUCTS</h5>
<h4><span>SUMMER</span>SALE</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. tellus sed augue semper porta. Mauris massa</p>
<p><button>purchASE NOW </button></p>');


