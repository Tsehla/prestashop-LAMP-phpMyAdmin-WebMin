INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('3','_ID_LANG_','Hot deals','','look book 2016','Purchase now','http://www.prestashop.com&utm_campaign=back-office-EN&utm_content=download','3c8f5d70a89b2df36d6039e43715047c0458122b_home-1-slide-a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','Hot deals','','look book 2016','Purchase now','#','c18c79050d5298df28f55bfbc5daa74f04cad8ae_home-3-slide-b.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('10','_ID_LANG_','New Women\'s','','Clothing styles','Purchase now','#','4614a3629cd92221e4a53855bd8e565c1e9bb9a5_home-3-slide-c.jpg');


