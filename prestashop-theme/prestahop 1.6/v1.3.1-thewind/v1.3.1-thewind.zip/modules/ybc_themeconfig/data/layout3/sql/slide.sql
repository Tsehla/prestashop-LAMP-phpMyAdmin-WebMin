INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('10','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','5','1','random','26%','10%','10%','type3','center','center','80%','c2_fs_70 c2_ls_10 c2_cl_w c1_cl_w','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','4','1','random','25%','7%','10%','type2','left','center','53%','c1_cl_red c1_fs_50 c2_ls_5 c2_fs_50','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('10','0','1','random','23%','7%','10%','type4','left','center','50%','c1_cl_red c1_fs_50 c2_ls_5 c2_fs_40','#');


