INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('1','_ID_LANG_','Home');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('2','_ID_LANG_','Women\'s');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('4','_ID_LANG_','Accessories');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('5','_ID_LANG_','Contact');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('7','_ID_LANG_','Blog');


INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('1','_ID_LANG_','Dresses','','<ul>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/10-evening-dresses\">Evening Dress</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/7-blouses\">Blouses</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/6-accessories\">Accessories</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/5-tshirts\">Tshirts</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/3-women\">Women</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/8-dresses\">Dresses</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('6','_ID_LANG_','Trousers','','<ul>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/10-evening-dresses\">Evening Dress</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/7-blouses\">Blouses</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/6-accessories\">Accessories</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/5-tshirts\">Tshirts</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/3-women\">Women</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/8-dresses\">Dresses</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('7','_ID_LANG_','Maternity','','<ul>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/new-products\">Dresses New</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/7-blouses\">Blouses</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/best-sales\">Best Sales</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/prices-drop\">Women special</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/6-accessories\">Accessories</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/10-evening-dresses\">Evening Dress</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('12','_ID_LANG_','Full width','','<ul>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/new-products\">Dresses New</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/7-blouses\">Blouses</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/best-sales\">Best Sales</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/prices-drop\">Women special</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/6-accessories\">Accessories</a></li>
<li><a href=\"http://theme.yourbestcode.com/thewind/en/10-evening-dresses\">Evening Dress</a></li>
</ul>');


INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('1','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('2','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('3','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('4','_ID_LANG_','Column 3/12','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('9','_ID_LANG_','Full width','');


