INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('1','HOME','','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('2','CUSTOM','#','0','0','0','FULL','100','','','','','','#4a4a4a','title','1','bottom','','','ybc_sale','1','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('4','CUSTOM','#','0','0','0','LEFT','25','','','','','','#4a4a4a','title','1','bottom','','','','1','','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('5','CONTACT','','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','','1','8');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('7','CUSTOM','http://theme.yourbestcode.com/thewind/blog','0','0','0','FULL','100','#333333','#777777','','#FF564B','#DDDDDD','#FFFFFF','title','1','bottom','','','ybc_new','1','','1','7');


INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('1','1','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:4:{i:0;s:1:\"3\";i:1;s:2:\"10\";i:2;s:1:\"7\";i:3;s:1:\"9\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','','','1');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('6','2','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:4:{i:0;s:1:\"3\";i:1;s:2:\"10\";i:2;s:1:\"7\";i:3;s:1:\"9\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','','','2');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('7','3','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:6:{i:0;s:1:\"3\";i:1;s:1:\"4\";i:2;s:1:\"8\";i:3;s:2:\"10\";i:4;s:1:\"7\";i:5;s:1:\"9\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','1','1','1','','1','','','2');
INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('12','9','HTML','a:5:{s:8:\"CATEGORY\";a:2:{s:27:\"categories_list_include_sub\";s:1:\"1\";s:10:\"categories\";a:4:{i:0;s:1:\"3\";i:1;s:2:\"10\";i:2;s:1:\"7\";i:3;s:1:\"9\";}}s:7:\"PRODUCT\";a:1:{i:0;s:0:\"\";}s:3:\"CMS\";a:0:{}s:4:\"MNFT\";a:0:{}s:6:\"CUSTOM\";a:2:{s:5:\"label\";s:0:\"\";s:4:\"link\";s:0:\"\";}}','0','1','1','','1','','','1');


INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('1','2','1','','0','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('2','2','1','','0','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('3','2','1','','0','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('4','2','1','','0','1','','3_12','mega-1.jpg','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('9','4','1','','0','0','','12_12','','0','1');


