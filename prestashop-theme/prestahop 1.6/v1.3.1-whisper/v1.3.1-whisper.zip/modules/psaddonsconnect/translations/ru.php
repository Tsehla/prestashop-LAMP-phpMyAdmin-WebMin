<?php
global $_MODULE;
$_MODULE = array();
$_MODULE['<{psaddonsconnect}prestashop>psaddonsconnect_59c29985e3ebd042bef35631307d47a2'] = '';
$_MODULE['<{psaddonsconnect}prestashop>psaddonsconnect_475068f091f2d33ff771152fcc008714'] = '';
$_MODULE['<{psaddonsconnect}prestashop>psaddonsconnect_bb8956c67b82c7444a80c6b2433dd8b4'] = 'Вы уверены, что хотите удалить этот модуль?';
$_MODULE['<{psaddonsconnect}prestashop>psaddonsconnect_f87b9438e8de65a83e7a3ef56a9d23fb'] = 'Во время установки произошла ошибка.
Пожалуйста, свяжитесь с нами через сайт Addons';
$_MODULE['<{psaddonsconnect}prestashop>psaddonsconnect_78d320af42aca685d1fcd1113f09939e'] = 'Во время удаления произошла ошибка.
Пожалуйста, свяжитесь с нами через сайт Addons';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_7be54024e8bcd26fb590144aac97ba5f'] = '';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_cdcbcbc85ab3a853719bf11c276be7e1'] = 'Подключитесь к своему аккаунту для обновления (безопасности и функционала) всех ваших модулей.';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_1d73e09f3283e07069c6603eb3fabd6e'] = 'После подключения вы также сможете получать еженедельные рекомендации от своего бэк-офиса.';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_78f1d8c0b05e45e2fd5e2a9549e87589'] = 'Подключение к площадке Prestashop';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_8438266d57cf7e6781947849125ce017'] = 'Подключение к площадке Prestashop';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_4d2e8ed55ef375754bd7c9a78ccf7312'] = 'Свяжите свой магазин с аккаунтом Addons, чтобы автоматически получать важные обновления для приобретенных модулей. У вас еще нет аккаунта?';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_cedcf6fe65a8f2849fe11e316d6c9923'] = 'Зарегистрироваться';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_b357b524e740bc85b9790a0712d84a30'] = 'Адрес электронной почты';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_dc647eb65e6711e155375218212b3964'] = 'Пароль';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_878530871f0db73f004f5bd6591eeb76'] = 'Запомнить меня';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_2283584ec794bba6bb3a045853c87a61'] = 'ВПЕРЕД!';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_01a569ddc6cf67ddec2a683f0a5f5956'] = 'Забыли пароль?';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_78f1d8c0b05e45e2fd5e2a9549e87589'] = 'Подключение к площадке PrestaShop';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_c4ab50c3866c157bd46ed930ab305eb8'] = 'Совет дня';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_754498b2927bb601e4072f1d7385b984'] = 'Смотреть всю подборку';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_bc74efcae6217e0f80935d5307ddfea0'] = 'Полезные ссылки';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_7f3ef03ec9e8db5866a9f02350cfe746'] = 'Модули, чтобы';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_43bcc86750a173fe79da9ed9fef3e689'] = 'повысить трафик';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_7f3ef03ec9e8db5866a9f02350cfe746'] = 'Модули, чтобы';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_e397072999e5885f96e030977f733b3d'] = 'улучшить общение';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_7f3ef03ec9e8db5866a9f02350cfe746'] = 'Модули, чтобы';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_670fdaa07cd73dd95da8f0bfd1ce0b51'] = 'увеличить среднюю корзину';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_dd00e3e6f9adb69272dfad842320bd4e'] = 'Подборка модулей, рекомендованных для';
$_MODULE['<{psaddonsconnect}prestashop>dashboard_zone_one_9494a44a23e3dbca3a5c8af826dd3c9c'] = 'моей сферы деятельности';
