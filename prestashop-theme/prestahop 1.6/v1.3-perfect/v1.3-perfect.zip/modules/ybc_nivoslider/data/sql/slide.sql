INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','0','1','random','26%','5%','5%','type1','right','left','50%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','1','1','random','25%','1px','6%','type3','left','left','70%','','#');


