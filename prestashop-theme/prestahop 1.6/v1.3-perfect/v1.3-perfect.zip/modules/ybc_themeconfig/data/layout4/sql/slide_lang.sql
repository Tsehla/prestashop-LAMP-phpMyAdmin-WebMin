INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','Buy now with confidence','','Powerful notebooks','Purchase now','#','7ed953c4239aa3add3fda7bff2738d4baac54fda_Layer-14-copy.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','The power of 10','','HTC Desire 628 dual sim','Purchase now','#','90fa53641c4822a811fcdce96b542732318348c9_slider4-2.jpg');


