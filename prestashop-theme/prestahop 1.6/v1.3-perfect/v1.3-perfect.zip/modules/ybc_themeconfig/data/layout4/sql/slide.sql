INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('4','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','2','1','random','64%','1%','1%','type4','center','center','100%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('4','0','1','random','70%','1%','1%','type3','center','center','100%','','#');


