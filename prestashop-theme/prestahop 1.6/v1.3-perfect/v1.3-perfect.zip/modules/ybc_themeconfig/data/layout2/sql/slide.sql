INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('5','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('5','0','1','random','31%','10%','10%','type4','center','center','100%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','5','1','random','31%','10%','10%','type3','center','center','100%','','#');


