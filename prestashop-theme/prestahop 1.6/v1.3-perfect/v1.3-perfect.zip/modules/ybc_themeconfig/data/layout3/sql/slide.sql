INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','7','1','random','26%','10%','1px','type3','right','center','60%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','6','1','random','26%','10%','10%','type1','center','center','100%','','#');


