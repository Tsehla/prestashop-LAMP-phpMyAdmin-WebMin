INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('2','_ID_LANG_','Welcome to our online store','<p>In scelerisque fermentum ipsum id lobortis. Phasellus feugiat nulla sit amet massa interdum finibus. Curabitur accumsan nibh metus sodales tristique volutpat.</p>
<div class=\"box-bt-shop\"><a class=\"bt bt-shop\" href=\"#\">Shop Online Now</a></div>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('14','_ID_LANG_','Tesimonials','<h3>Happy Customers</h3>
<div id=\"box-tesimonial\">
<div class=\"slider\">
<div class=\"avatar\"><img alt=\"banner 1\" src=\"http://theme.yourbestcode.com/perfect/img/cms/avatar1.png\" width=\"110\" height=\"110\" /></div>
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
By <span class=\"tesi_name\">Diamond Gate</span> <span class=\"work\"> - Web developer</span></div>
</div>
<div class=\"slider\">
<div class=\"avatar\"><img alt=\"banner 1\" src=\"http://theme.yourbestcode.com/perfect/img/cms/avatar1.png\" width=\"110\" height=\"110\" /></div>
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
By <span class=\"tesi_name\">Diamond Gate</span> <span class=\"work\"> - Web developer</span></div>
</div>
<div class=\"slider\">
<div class=\"avatar\"><img alt=\"banner 1\" src=\"http://theme.yourbestcode.com/perfect/img/cms/avatar1.png\" width=\"110\" height=\"110\" /></div>
<div class=\"content-tesimonial\">
<p>Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent adipiscing elit. Integer nec odio. Praesent</p>
By <span class=\"tesi_name\">Diamond Gate</span> <span class=\"work\"> - Web developer</span></div>
</div>
</div>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('21','_ID_LANG_','FREE SHIPPING WORLDWIDE','<p><i class=\"fa fa-recycle\" aria-hidden=\"true\">.</i></p>
<h4>FREE SHIPPING WORLDWIDE</h4>
<p>We offer free shipping for all orders over $200</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('22','_ID_LANG_','unlimited customer support','<p><i class=\"fa fa-headphones\" aria-hidden=\"true\">.</i></p>
<h4>unlimited customer support</h4>
<p>Free customer support 24/7, call us any time</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('23','_ID_LANG_','return & exchange','<p><i class=\"fa fa-refresh\" aria-hidden=\"true\">.</i></p>
<h4>Free return and exchange</h4>
<p>You may return products purchases without fee</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('41','_ID_LANG_','Custom furniture design','<div class=\"content-right col-md-8 col-sm-8\">
<h3>Custom furniture design</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh.</p>
</div>');


