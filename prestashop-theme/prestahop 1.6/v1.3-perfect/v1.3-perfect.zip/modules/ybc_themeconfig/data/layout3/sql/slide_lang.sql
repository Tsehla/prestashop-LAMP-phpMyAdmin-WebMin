INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','WELCOME TO OUR STORE','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec <br />odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.</p>','NEW FURNITURE DESIGN','Purchase Now','#','7f07e805bbaf812571a3ca7e82293531cecd399a_slider3-2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','WELCOME TO OUR STORE','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec <br />odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi.</p>','NEW FURNITURE DESIGN','Purchase Now','#','91864a5679052f762719bec44db19d2125c89557_lamp.jpg');


