INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('1','_ID_LANG_','Home');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('2','_ID_LANG_','Shoes');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('4','_ID_LANG_','Accessories');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('5','_ID_LANG_','Contact');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('8','_ID_LANG_','Blog');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('10','_ID_LANG_','Dresses');
INSERT INTO `_DB_PREFIX_ybc_mm_menu_lang` VALUES('11','_ID_LANG_','Watches');


INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('4','_ID_LANG_','','','');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('5','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('6','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('7','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('8','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('9','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('10','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('11','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('12','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('13','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('14','_ID_LANG_','Adipiscing','','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_block_lang` VALUES('15','_ID_LANG_','Hot deals','','');


INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('6','_ID_LANG_','Women\'s','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('7','_ID_LANG_','Accessories','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('8','_ID_LANG_','Fashion','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('9','_ID_LANG_','Blouses','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('10','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('11','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('12','_ID_LANG_','Contact link','<ul><li><a class=\"ybc-mm-item-link\" href=\"http://theme.yourbestcode.com/camila/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout1\">Contact page 1</a></li>
<li><a class=\"ybc-mm-item-link\" href=\"http://theme.yourbestcode.com/camila/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout2\">Contact page 2</a></li>
<li><a class=\"ybc-mm-item-link\" href=\"http://theme.yourbestcode.com/camila/en/contact-us?YBC_TC_CONTACT_FORM_LAYOUT=layout3\">Contact page 3</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('13','_ID_LANG_','Cosmetics','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('14','_ID_LANG_','Lorem ipsum','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('15','_ID_LANG_','Lorem ipsum','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('16','_ID_LANG_','Categories','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('17','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('18','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('19','_ID_LANG_','Samsung','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('20','_ID_LANG_','Sony','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('21','_ID_LANG_','Microsoft','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('22','_ID_LANG_','Asus','<ul>
<li><a href=\"#\">Lorem ipsum</a></li>
<li><a href=\"#\">Dolor sit</a></li>
<li><a href=\"#\">Amet consectetur</a></li>
<li><a href=\"#\">Adipiscing</a></li>
<li><a href=\"#\">Quis nostrud</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('23','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('24','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('25','_ID_LANG_','Main page','<ul><li><a href=\"http://theme.yourbestcode.com/camila/blog\">Main page</a></li>
<li><a href=\"http://theme.yourbestcode.com/camila/en/blog/post/1-sample-post1.html\">Post page</a></li>
<li><a href=\"http://theme.yourbestcode.com/camila/en/blog/category/1-fashion.html\">Category page</a></li>
<li><a href=\"http://theme.yourbestcode.com/camila/en/blog/author/1-dola-nguyen\">Author page</a></li>
</ul>');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('30','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('31','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('32','_ID_LANG_','Category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('33','_ID_LANG_','image','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('34','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('35','_ID_LANG_','category','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('36','_ID_LANG_','Hot deals','');
INSERT INTO `_DB_PREFIX_ybc_mm_column_lang` VALUES('37','_ID_LANG_','html block','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam. Ut enim ad minima veniam, quis nostrum exercitationem</p>');


