INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('1','HOME','','0','0','0','FULL','100','','','','','','','','1','','','','','1','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('2','CUSTOM','http://theme.yourbestcode.com/perfect/3-fashion','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('4','CUSTOM','http://theme.yourbestcode.com/perfect/5-accessories','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','1','11');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('5','CONTACT','','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','','1','13');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('8','CUSTOM','http://theme.yourbestcode.com/perfect/blog','0','0','0','LEFT','','','','','','','','title','1','bottom','','','','1','','1','12');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('10','CUSTOM','http://theme.yourbestcode.com/perfect/8-dresses','0','0','0','FULL','100','#333333','#777777','','#FF564B','#DDDDDD','#FFFFFF','title','1','bottom','','','','1','','1','10');


INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('4','4','HTML','1','1','1','1','model.jpg','1','','','4');


INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('6','2','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('7','2','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('8','2','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('9','2','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('10','2','1','','0','0','','6_12','bgmenu.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('11','2','1','','0','0','','6_12','bgmenu2.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('12','5','1','','0','1','','12_12','','0','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('13','7','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('14','7','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('15','7','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('16','7','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('17','7','1','','0','1','','6_12','hygiene-870763_960_720.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('18','7','1','','0','1','','6_12','perfume-1433654_960_720.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('19','9','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('20','9','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('21','9','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('22','9','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('23','9','1','','0','1','','6_12','imac-606765_960_720.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('24','9','1','','0','1','','6_12','laptop-computer-1245981_960_720.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('25','8','1','','0','1','','12_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('26','1','1','','0','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('27','1','1','','0','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('28','1','1','','0','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('29','1','1','','0','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('31','18','1','','1','1','','3_12','','1','7');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('32','18','1','','1','1','','3_12','','1','8');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('33','18','1','','1','1','','3_12','','1','9');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('34','18','1','','1','1','','3_12','','1','10');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('35','18','1','','0','1','','6_12','mn-2.jpg','1','11');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('36','18','1','','0','1','','6_12','mn-21.jpg','1','12');


