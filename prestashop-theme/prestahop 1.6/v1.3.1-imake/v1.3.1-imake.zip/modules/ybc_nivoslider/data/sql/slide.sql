INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','0','1','random','6%','','25%','type4','right','center','40%','c2_ls_5','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','3','1','random','7%','10%','10%','type1','center','center','60%','c2_ls_5','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','4','1','random','8%','10%','18%','type3','right','center','40%','','#');


