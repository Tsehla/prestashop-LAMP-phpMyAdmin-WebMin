INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','Season sale 70% off all products','','Look book 2016','Purchase now','#','d986e15e932e67f62e202c74ae934a0fc2c8ad0c_slider1a.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','New product arrivals','','Luxury women’s fashion','Purchase now','http://www.prestashop.com&utm_campaign=back-office-EN&utm_content=download','15590f8b6c526fa1c66c47e2b866f50509441e89_slider-1b.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('3','_ID_LANG_','Save up to 20% for al dresses','','New Party dresses','Purchase now','http://www.prestashop.com&utm_campaign=back-office-EN&utm_content=download','d545893277660c9255d46344b3ff445afdfb8d91_slider1c.jpg');


