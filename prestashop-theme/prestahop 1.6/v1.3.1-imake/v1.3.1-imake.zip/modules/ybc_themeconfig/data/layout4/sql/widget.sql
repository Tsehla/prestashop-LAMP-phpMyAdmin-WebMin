INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('13','displayTopColumn','1','1','1','1','banner-layout41.jpg','','#','12');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('27','displayTopColumn','1','1','1','1','banner-layout42.jpg','','','13');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('28','displayTopColumn','1','1','1','1','banner-layout43.jpg','','','14');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('29','displayTopColumn','1','1','1','1','banner-layout44.jpg','','','15');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('30','displayTopColumn','1','1','1','1','banner-layout45.jpg','','','16');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('33','ybcCustom2','1','1','1','1','banner-layout46.jpg','','','4');


