INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('10','_ID_LANG_','Bag','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('11','_ID_LANG_','New headphone','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('12','_ID_LANG_','Apple iphone','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('15','_ID_LANG_','New mac book air','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('21','_ID_LANG_','delivery','<p><i class=\"fa fa-truck\" aria-hidden=\"true\">.</i></p>
<h4>Free delivery</h4>
<p>All orders over $200</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('22','_ID_LANG_','support','<p><i class=\"fa fa-headphones\" aria-hidden=\"true\">.</i></p>
<h4>free support</h4>
<p>24/7 customer support</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('23','_ID_LANG_','return & exchange','<p><i class=\"fa fa-refresh\" aria-hidden=\"true\">.</i></p>
<h4>return & exchange</h4>
<p>All products in 30 working days</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('24','_ID_LANG_','Paypal checkout','<p><i class=\"fa fa-paypal\" aria-hidden=\"true\">.</i></p>
<h4>Paypal checkout</h4>
<p>We support Paypal checkout</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('26','_ID_LANG_','Welcome to our digital store','<h4>Welcome to our digital store</h4>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. libero. Sed cursus ante dapibus diam. Sed nisi</p>
<p><a class=\"bt-banner\" href=\"#\">Purchase now</a></p>');


