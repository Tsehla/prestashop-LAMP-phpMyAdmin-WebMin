INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','Premium design','','PRESTASHOP THEME','PURCHASE NOW','#','1fa8e47f9f4bae17529105a0e7d297ab81a233f9_2-img.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('5','_ID_LANG_','Thinner and Faster','','NEW MAC BOOK AIR 2016','PURCHASE NOW','#','2e481e4238a51a3e1c072e5510136ca6e53112ff_1-img.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','New arrivals','','XF CAMERA SYSTEM','PURCHASE NOW','#','a0ec85a66a5c4b795e55d839fd9e35d0a5ddc6cc_3-img.jpg');


