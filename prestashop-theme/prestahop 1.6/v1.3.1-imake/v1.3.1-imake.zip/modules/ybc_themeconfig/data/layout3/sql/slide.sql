INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('4','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('5','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('4','2','1','random','9%','10%','14%','type1','right','center','40%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('5','1','1','random','7%','15%','10%','type4','left','center','40%','main_color_red','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','5','1','random','9%','10%','10%','type3','left','center','40%','','#');


