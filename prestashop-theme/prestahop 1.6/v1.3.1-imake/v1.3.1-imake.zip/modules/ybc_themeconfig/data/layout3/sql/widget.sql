INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('10','displayTopColumn','1','0','1','1','banner_layout31.jpg','','#','9');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('11','displayTopColumn','1','0','1','1','banner_layout32.jpg','','#','10');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('12','displayTopColumn','1','0','1','1','banner_layout33.jpg','','#','11');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('15','ybcCustom2','1','0','1','1','banner_layout31.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('21','ybcCustom5','1','0','1','1','','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('22','ybcCustom5','1','0','1','1','','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('23','ybcCustom5','1','0','1','1','','','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('24','ybcCustom5','1','0','1','1','','','','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('26','displayHome','1','0','1','1','banner_big_layout31.jpg','','','4');


