INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('1','_ID_LANG_','Payment logos','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('5','_ID_LANG_','Skill care','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('6','_ID_LANG_','Collection','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('7','_ID_LANG_','Cusmetics','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('8','_ID_LANG_','Elegance','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('9','_ID_LANG_','Make up','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('20','_ID_LANG_','Shampo','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('21','_ID_LANG_','delivery','<p><i class=\"fa fa-truck\" aria-hidden=\"true\">.</i></p>
<h4>Free delivery</h4>
<p>All orders over $200</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('22','_ID_LANG_','support','<p><i class=\"fa fa-headphones\" aria-hidden=\"true\">.</i></p>
<h4>free support</h4>
<p>24/7 customer support</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('23','_ID_LANG_','return & exchange','<p><i class=\"fa fa-refresh\" aria-hidden=\"true\">.</i></p>
<h4>return & exchange</h4>
<p>All products in 30 working days</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('24','_ID_LANG_','Paypal checkout','<p><i class=\"fa fa-paypal\" aria-hidden=\"true\">.</i></p>
<h4>Paypal checkout</h4>
<p>We support Paypal checkout</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('25','_ID_LANG_','Wo beauty','');


