INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','70% off all products','','Women’s beauty','Purchase now','#','ad4cf6b62f74afad50ab8d715e76834d104d40d2_1-img.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','Best skin care products','','for beautiful skin','Purchase now','#','b261d4e5cd74cf750ae7a15a00fad7fd5f9f6a23_2-img.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','Top 25 Best Perfumes For Women','','wormen’s Fragrances','Purchase now','#','7a909dfef9bf474ca5431eaac4478ed949590c40_3-img.jpg');


