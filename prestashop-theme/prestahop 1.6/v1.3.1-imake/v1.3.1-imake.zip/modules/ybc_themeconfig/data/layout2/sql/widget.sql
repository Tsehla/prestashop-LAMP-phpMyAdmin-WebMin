INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('1','ybcPaymentLogo','1','0','1','1','paymentlogos.png','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('5','displayTopColumn','1','0','1','1','banner-layout-21.jpg','','#','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('6','displayTopColumn','1','0','1','1','banner-layout-22.jpg','','#','5');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('7','displayTopColumn','1','0','1','1','banner-layout-23.jpg','','#','6');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('8','displayTopColumn','1','0','1','1','banner-layout-24.jpg','','#','7');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('9','displayTopColumn','1','0','1','1','banner-layout-25.jpg','','#','8');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('20','displayHome','1','0','1','1','banner-layout-big1.jpg','','http://demo.yourbestcode.com/do/imake/en/16-face','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('21','ybcCustom5','1','0','1','1','','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('22','ybcCustom5','1','0','1','1','','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('23','ybcCustom5','1','0','1','1','','','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('24','ybcCustom5','1','0','1','1','','','','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('25','displayHome','1','0','1','1','banner-layout-big 2.jpg','','http://demo.yourbestcode.com/do/imake/en/14-lips','2');


