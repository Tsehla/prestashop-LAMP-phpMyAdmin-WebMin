INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','6','1','random','6%','12%','10%','type1','left','center','40%','c2_ls_5','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','7','1','random','10%','10%','15%','type4','right','center','40%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','8','1','random','6%','10%','9%','type3','left','center','60%','','#');


