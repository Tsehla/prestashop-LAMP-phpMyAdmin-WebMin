INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('1','ybcPaymentLogo','1','0','1','1','paymentlogos.png','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('2','displayTopColumn','1','0','1','1','banner-small-1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('3','displayTopColumn','1','0','1','1','banner-small-2.jpg','','#','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('4','displayTopColumn','0','0','1','1','banner-3.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('14','displayHome','1','0','1','1','bg-tesimonial.png','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('19','ybcCustom3','1','1','1','1','cat1.jpg','','http://theme.yourbestcode.com/imake/en/4-tops','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('21','ybcCustom5','1','0','1','1','','','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('22','ybcCustom5','1','0','1','1','','','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('23','ybcCustom5','1','0','1','1','','','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('24','ybcCustom5','1','0','1','1','','','','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('35','ybcCustom3','1','1','1','1','cat-2.jpg','','http://theme.yourbestcode.com/imake/en/7-blouses','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('36','ybcCustom3','1','1','1','1','cat-3.jpg','','http://theme.yourbestcode.com/imake/en/5-tshirts','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('37','ybcCustom3','1','1','1','1','cat-4.jpg','','http://theme.yourbestcode.com/imake/en/9-casual-dresses','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('38','ybcCustom3','1','1','1','1','cat-5.jpg','','http://theme.yourbestcode.com/imake/en/10-evening-dresses','5');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('39','ybcCustom3','1','1','1','1','cat-6.jpg','','http://theme.yourbestcode.com/imake/en/11-summer-dresses','6');


