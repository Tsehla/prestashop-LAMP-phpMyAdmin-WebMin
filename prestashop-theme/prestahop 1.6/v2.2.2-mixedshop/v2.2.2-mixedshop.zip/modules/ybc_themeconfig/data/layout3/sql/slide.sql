INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','0','1','random','30%','10%','5%','type1','right','center','50%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','0','1','random','30%','10%','5%','type3','right','center','50%','','#');


