INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. <br /> Praesent libero. Sed cursus ante dapibus diam.</p>','Women’s Fashion','Purchase now','#','6fc268874b1eb90c90cf4686c96c47ca9ca51781_sl3-1.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. <br /> Praesent libero. Sed cursus ante dapibus diam.</p>','Men’s Fashion','Purchase now','#','cbdd5cb2ede94df81854073a2ac301a631d2c49e_sl3-2.jpg');


