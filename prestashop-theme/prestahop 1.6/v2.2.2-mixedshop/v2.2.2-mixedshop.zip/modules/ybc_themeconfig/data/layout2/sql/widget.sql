INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('47','displayTopColumn','1','1','1','1','','fa-headphones icon-headphones','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('48','displayTopColumn','1','1','1','1','','fa-paypal icon-paypal','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('49','displayTopColumn','1','1','1','1','','fa-plane','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('70','displayHomeTabContent','1','1','1','1','banner1.jpg','','#','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('71','displayHomeTabContent','1','1','1','1','men-watch.jpg','','#','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('72','displayHomeTabContent','1','1','1','1','street-girlt.jpg','','#','2');


