INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('47','_ID_LANG_','Online 24/7 support','','<p>Lorem ipsum dolor sit amet, consectetur olor adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('48','_ID_LANG_','Secure payment','','<p>Lorem ipsum dolor sit amet, consectetur olor adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('49','_ID_LANG_','Worldwide Delivery','','<p>Lorem ipsum dolor sit amet, consectetur olor adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('70','_ID_LANG_','Women’s bags','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('71','_ID_LANG_','Men’s watches','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('72','_ID_LANG_','Special designs','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('73','_ID_LANG_','Men’s Watches','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('74','_ID_LANG_','Women’s','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('75','_ID_LANG_','Men’s Shoes','','');


