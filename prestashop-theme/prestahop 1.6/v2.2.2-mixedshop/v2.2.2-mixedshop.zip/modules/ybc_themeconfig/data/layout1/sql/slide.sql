INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('4','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('5','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('4','0','1','random','15%','5%','3%','type2','right','left','46%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('5','0','1','random','28%','10%','10%','type3','right','left','45%','','#');


