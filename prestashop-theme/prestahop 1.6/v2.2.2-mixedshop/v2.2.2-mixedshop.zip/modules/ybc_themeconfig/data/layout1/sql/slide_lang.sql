INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','New Arrivals','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit. Integer nec odio. Praesent libero. <br /> Sed cursus ante dapibus diam.</p>','Men’s Fashion','Purchase now','#','8a3fcc7935dbc3a2e6a3b9b09c8bdea345184f0c_sl1-1.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('5','_ID_LANG_','New trends 2017','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit. Integer nec odio. Praesent libero. <br /> Sed cursus ante dapibus diam.</p>','Women’s Fashion','Purchase now','#','a9bf7063cdd53a94f01ead5750e6d2926ad78420_sl1-2.jpg');


