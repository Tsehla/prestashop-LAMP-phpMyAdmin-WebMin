INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','7','1','random','25%','10%','1px','type1','right','left','40%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','8','1','random','25%','1px','1px','type2','right','left','50%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','2','1','random','25%','1px','10%','type1','left','left','40%','','#');


