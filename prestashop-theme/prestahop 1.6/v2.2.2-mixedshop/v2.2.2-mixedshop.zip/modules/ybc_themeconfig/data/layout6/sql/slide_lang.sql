INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('6','_ID_LANG_','queen lipsticks','<p>Lorem ipsum dolor sit amet, consectetur adipiscing <br /> elit. Integer nec odio...</p>','New arrivals with big discounts','Purchase now','#','11377f8a6adedf095933f863a488b76003e7b147_slider3-2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('7','_ID_LANG_','enhance your charm','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit. Integer...</p>','Completely new and owesome','Purchase now','#','72f49dd69b0ef23887ea63593cb5eabd962b8c96_slider3-3.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','Supper shampoo','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing eli...</p>','For your attractive hair','Purchase now','#','ca19a707778412e4175b0b6097440417716bc62f_slider6.jpg');


