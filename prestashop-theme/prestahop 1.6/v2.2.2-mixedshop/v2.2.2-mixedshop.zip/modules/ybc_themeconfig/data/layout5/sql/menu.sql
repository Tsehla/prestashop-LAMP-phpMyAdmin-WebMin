INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('2','CUSTOM','http://demo.etssoft.net/cosmetic/3-make-up','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('4','CUSTOM','http://demo.etssoft.net/cosmetic/en/5-lip-sticks','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('10','CUSTOM','http://demo.etssoft.net/cosmetic/en/8-body','0','0','0','FULL','100','','','','','','#FFFFFF','title','1','bottom','','','','1','','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('11','CUSTOM','http://demo.etssoft.net/cosmetic/en/4-skin-care','0','0','0','FULL','100','','','','','','#FFFFFF','title','1','bottom','','','ybc_sale','1','','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_menu` VALUES('12','HOME','','0','0','0','FULL','100','','','','','','','title','1','bottom','','','','1','','','1','1');


INSERT INTO `_DB_PREFIX_ybc_mm_block` VALUES('4','4','HTML','1','1','1','1','model.jpg','1','','','4');


INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('6','2','1','','1','1','border_right','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('7','2','1','','1','1','border_right p_l_20','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('8','2','1','','1','1','border_right p_l_20','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('10','2','1','','0','0','content_center_midle p_l_20','3_12','product-makeup1.jpg','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('13','7','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('14','7','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('15','7','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('16','7','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('17','7','1','','0','1','','6_12','hygiene-870763_960_720.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('18','7','1','','0','1','','6_12','perfume-1433654_960_720.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('19','9','1','','1','1','','3_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('20','9','1','','1','1','','3_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('21','9','1','','1','1','','3_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('22','9','1','','1','1','','3_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('23','9','1','','0','1','','6_12','imac-606765_960_720.jpg','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('24','9','1','','0','1','','6_12','laptop-computer-1245981_960_720.jpg','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('25','8','1','','0','1','','12_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('26','1','1','','0','1','','2_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('27','1','1','','0','1','','2_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('28','1','1','','0','1','','2_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('29','1','1','','0','1','','2_12','','1','4');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('30','11','1','#','1','1','border_right','2_12','','1','1');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('32','11','1','','1','1','border_right p_l_20','2_12','','1','2');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('33','11','1','','1','1','border_right p_l_20','2_12','','1','3');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('39','1','1','','0','1','','2_12','','1','5');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('40','1','1','','0','1','','2_12','','1','6');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('41','12','1','','0','1','','2_12','','1','7');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('42','12','1','','0','1','','2_12','','1','8');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('43','12','1','','0','1','','2_12','','1','9');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('44','12','1','','0','1','','2_12','','1','10');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('45','12','1','','0','1','','2_12','','1','11');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('46','12','1','','0','1','','2_12','','1','12');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('47','11','1','','1','1','border_right p_l_20','2_12','','1','13');
INSERT INTO `_DB_PREFIX_ybc_mm_column` VALUES('48','11','1','','0','0','content_center_midle','4_12','oganic-cosmestoc1.jpg','1','14');


