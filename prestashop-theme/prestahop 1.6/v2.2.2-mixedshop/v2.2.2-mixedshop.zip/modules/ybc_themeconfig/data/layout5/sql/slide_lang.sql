INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','Instant face lift','<p>Archive your beatiful white skine and attract <br /> people’s eyes is that easy...</p>','Safely whiten your skin in 1 week','Purchase now','#','4328f67cb28f5788a770e5e840ce120e6b5d4907_slider1-2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('3','_ID_LANG_','natural skin care','<p>Save up to 40% when purchase our band name<br /> products...</p>','The World’s largest cosmetic store','Purchase now','#','8ed10a3c637df696ec5e1c07992642273bc37856_slider2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','Natural products','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit. Integer...</p>','Completely new and awesome','Purchase now','#','4dfc8bc92946b6e2f3a026d937101a36efcfd87a_slider5.jpg');


