INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('47','ybcCustom1','1','1','1','1','','fa-exchange','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('48','ybcCustom1','1','1','1','1','','icon_genius','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('49','ybcCustom1','1','1','1','1','','fa-truck','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('73','displayTopColumn','1','1','1','1','layout2_top-1.jpg','','http://demo.etssoft.net/cosmetic/4-skin-care','4');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('74','displayTopColumn','1','1','1','1','layout2_top-2.jpg','','#','5');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('75','displayTopColumn','1','1','1','1','layout2_top-3.jpg','','http://demo.etssoft.net/cosmetic/8-body','6');


