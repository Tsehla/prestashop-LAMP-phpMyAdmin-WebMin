INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('47','_ID_LANG_','Money back guarantee','','<p>Lorem ipsum dolor sit amet, consectetur olor adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('48','_ID_LANG_','Premium products & services','','<p>Lorem ipsum dolor sit amet, consectetur olor adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('49','_ID_LANG_','Free shipping','','<p>Lorem ipsum dolor sit amet, consectetur olor adipiscing elit</p>');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('73','_ID_LANG_','Skin care','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('74','_ID_LANG_','Beauty foods','','');
INSERT INTO `_DB_PREFIX_ybc_widget_widget_lang` VALUES('75','_ID_LANG_','Body care','','');


