INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','4','1','random','18%','4%','10%','type2','left','left','70%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','3','1','random','18%','5%','10%','type1','left','left','70%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','1','1','random','22%','10%','1%','type1','right','left','44%','','#');


