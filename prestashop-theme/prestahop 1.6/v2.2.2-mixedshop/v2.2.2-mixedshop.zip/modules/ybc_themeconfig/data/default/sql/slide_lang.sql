INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','Women’s Perfume','<p>Save up to 40% when purchase our band name<br /> perfumes...</p>','The World’s largest cosmetic store','Purchase Now','#','3f66f23954c22c6d439b0e41d429ed94caae0539_slider1.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','Instant face lift','<p>Archive your beatiful white skine and attract <br /> people’s eyes is that easy...</p>','Safely whiten your skin in 1 week','Purchase now','#','4328f67cb28f5788a770e5e840ce120e6b5d4907_slider1-2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('4','_ID_LANG_','for your charm','<p>Lorem ipsum dolor sit amet, consectetur <br /> adipiscing elit. Integer...</p>','Completely new and owesome','Purchase now','#','3715742ef66f2c1c7541776768a09b28557b9f0a_slider2-2.jpg');


