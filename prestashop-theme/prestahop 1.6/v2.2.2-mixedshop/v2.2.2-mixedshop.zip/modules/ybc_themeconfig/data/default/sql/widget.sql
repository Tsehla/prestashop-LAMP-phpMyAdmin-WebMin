INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('47','ybcCustom1','1','1','1','1','','fa-exchange','','3');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('48','ybcCustom1','1','1','1','1','','icon_genius','','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('49','ybcCustom1','1','1','1','1','','fa-truck','','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('70','displayTopColumn','1','1','1','1','top-1.jpg','','http://demo.etssoft.net/cosmetic/4-skin-care','1');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('71','displayTopColumn','1','1','1','1','top-2.jpg','','http://demo.etssoft.net/cosmetic/en/8-body','2');
INSERT INTO `_DB_PREFIX_ybc_widget_widget` VALUES('72','displayTopColumn','1','1','1','1','top-3.jpg','','http://demo.etssoft.net/cosmetic/3-make-up','3');


