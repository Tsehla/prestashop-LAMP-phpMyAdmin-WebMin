/**
 * 2007-2022 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 *  @author ETS-Soft <etssoft.jsc@gmail.com>
 *  @copyright  2007-2022 ETS-Soft
 *  @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

$(document).ready(function () {
    if (ETS_HD_PROCESS_LINK && ($('.ets_hd_menu_item.tickets').length > 0 || $('#subtab-AdminEtsHDTickets').length > 0)) {
        $.ajax({
            type: 'get',
            url: ETS_HD_PROCESS_LINK,
            data: {
                action: 'nBTickets',
                ajax: 1,
            },
            dataType: 'json',
            success: function (json) {
                if (json) {
                    var ele = $('.ets_hd_menu_item.tickets span.no_read'),
                        quickTab = $('#subtab-AdminEtsHDTickets span.no_read'),
                        nb = parseInt(json.nb)
                    ;
                    if (ele.length > 0) {
                        if (nb > 0) {
                            ele.html(nb);
                        } else
                            ele.remove();
                    }
                    if (nb > 0) {
                        if (ele.length > 0)
                            ele.html(nb);
                        else
                            $('.ets_hd_menu_item.tickets a').append('<span class="no_read">' + nb + '</span>');
                        if (quickTab.length > 0) {
                            quickTab.html(nb);
                        } else
                            $('#subtab-AdminEtsHDTickets > a').append('<span class="no_read">' + nb + '</span>');
                    } else {
                        ele.remove();
                        quickTab.remove();
                    }
                }
            }
        })
    }
});