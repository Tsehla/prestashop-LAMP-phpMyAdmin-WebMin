/**
 * 2007-2022 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 *  @author ETS-Soft <etssoft.jsc@gmail.com>
 *  @copyright  2007-2022 ETS-Soft
 *  @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */
 $(document).ready(function(){
    if($('a.btn-help.btn-sidebar').length && $('.admincustomers').length && $('#customer_filter_form').length==0)
    {
        $('a.btn-help.btn-sidebar').before('<a class="btn btn-outline-secondary ets_hd_create_ticket_as_customer" href="'+ets_hd_link_create_ticket_as_customer+'" title="'+Create_ticket_text+'" data-url="'+ets_hd_link_create_ticket_as_customer+'" target="_blank"> '+Create_ticket_text+' </a>')
    }
    else if($('.admincustomers').length && $('#customer_filter_form .js-bulk-action-checkbox').length)
    {
       $('#customer_filter_form .js-bulk-action-checkbox').each(function(){
            var idCustomer = $(this).val();
            $(this).parents('tr').find('.dropdown-menu').append('<a class="btn tooltip-link js-link-row-action dropdown-item" target="_blank" href="'+ets_hd_link_create_ticket_as_customer+'&id_customer='+idCustomer+'" data-confirm-message="" data-clickable-row=""><i class="material-icons fa fa-plus"></i> '+Create_ticket_text+'</a>');
       }); 
    }
    else if($('#order-view-page').length)
    {
        $('#order-view-page .order-navigation').before('<a class="btn btn-action ets_hd_create_ticket_as_customer" href="'+ets_hd_link_create_ticket_as_customer+'" title="'+Create_ticket_text+'" data-url="'+ets_hd_link_create_ticket_as_customer+'" target="_blank"><i class="fa fa-plus"></i> '+Create_ticket_text+' </a>');
    }
});