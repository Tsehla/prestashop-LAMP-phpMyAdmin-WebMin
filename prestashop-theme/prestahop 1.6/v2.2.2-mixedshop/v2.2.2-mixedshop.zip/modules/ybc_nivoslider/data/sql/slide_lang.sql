INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('1','_ID_LANG_','New trends 2017','','Luxury Women’s HandBags','Shop now','#','09175afadadb7463d560d8a56fa97e2e8f044fa6_slider1.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','New arrivals','','Women\'s accessories','Shop now','#','160da35ac1f9aa960171772ae047ed44f7453f68_girl-copy.jpg');


