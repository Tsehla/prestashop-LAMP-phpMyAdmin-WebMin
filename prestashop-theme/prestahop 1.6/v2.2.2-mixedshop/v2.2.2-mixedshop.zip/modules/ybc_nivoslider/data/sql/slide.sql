INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','0','1','random','32%','4%','2%','type1','right','center','50%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','0','1','random','32%','4%','1%','type4','right','center','50%','','#');


