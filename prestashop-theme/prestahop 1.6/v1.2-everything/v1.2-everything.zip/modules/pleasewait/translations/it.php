<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pleasewait}prestashop>pleasewait_0b171b59d90e2a5595bae5ae075d8bd1'] = 'Attendere prego...!';
$_MODULE['<{pleasewait}prestashop>pleasewait_6e5a2ae4d41d81d1439888aafed7faf5'] = 'Visualizzare l\'icona di carico durante il caricamento tuo sito web';
$_MODULE['<{pleasewait}prestashop>pleasewait_92328ef0a137839f00cf029c11501175'] = 'Abilita carico icona';
$_MODULE['<{pleasewait}prestashop>pleasewait_6d6c669b98589d5cd2abea03d3cea936'] = 'Caricamento tipo di icona';
$_MODULE['<{pleasewait}prestashop>pleasewait_fc23ffe3bc715a46cc8b63071ded5fda'] = 'dimensione icona';
$_MODULE['<{pleasewait}prestashop>pleasewait_4c2a8fe7eaf24721cc7a9f0175115bd4'] = 'Messaggio';
$_MODULE['<{pleasewait}prestashop>pleasewait_fa69ac6795d55bd7a44fe47ae4a7a854'] = 'Display a casa solo page';
$_MODULE['<{pleasewait}prestashop>pleasewait_534b7c706186028f1b4f51344bbca176'] = 'colore icona';
$_MODULE['<{pleasewait}prestashop>pleasewait_5f111ae4c490902059da2004cbc8b424'] = 'Colore del testo';
$_MODULE['<{pleasewait}prestashop>pleasewait_368d9ac76af05f714092bc808a426bfc'] = 'Colore di sfondo';
$_MODULE['<{pleasewait}prestashop>pleasewait_254f642527b45bc260048e30704edb39'] = 'Configurazione';
$_MODULE['<{pleasewait}prestashop>pleasewait_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{pleasewait}prestashop>pleasewait_93cba07454f06a4a960172bbd6e2a435'] = 'sì';
$_MODULE['<{pleasewait}prestashop>pleasewait_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{pleasewait}prestashop>pleasewait_7cc92687130ea12abb80556681538001'] = 'Si è verificato un errore durante il processo di caricamento delle immagini.';
$_MODULE['<{pleasewait}prestashop>form_9f5eba7179014f3c071cba0c406523fc'] = 'Visualizza tutti i tipi di carico di icone';
