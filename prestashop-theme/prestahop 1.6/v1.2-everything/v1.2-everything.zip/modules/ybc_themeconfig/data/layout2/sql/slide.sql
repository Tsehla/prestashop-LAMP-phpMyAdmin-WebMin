INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('4','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('6','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('4','0','1','random','5%','1px','10%','type2','left','left','50%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('6','0','1','random','10%','10%','1px','type3','right','left','38%','','#');


