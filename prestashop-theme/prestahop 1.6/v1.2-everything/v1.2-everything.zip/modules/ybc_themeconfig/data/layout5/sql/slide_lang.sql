INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('3','_ID_LANG_','New arrivals','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit <br />odio. Praesent libero. Sed cursus ante dapibus dia</p>','Men’s fashion','Purchase now','#','5de937a425f52319f6f7e2f8a91bcea4c7c734ba_slider-5.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','Women’s accesories','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br /> odio. Praesent libero. Sed cursus ante dapibus dia</p>','Jewellery','Purchase now','#','8758ae671526c07438b215a3502dc084564f8f74_4-2.jpg');


