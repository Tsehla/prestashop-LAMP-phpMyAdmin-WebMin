INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('3','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('3','0','1','random','16%','10%','','type3','left','left','55%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','0','1','random','16%','10%','10%','type2','left','left','55%','','#');


