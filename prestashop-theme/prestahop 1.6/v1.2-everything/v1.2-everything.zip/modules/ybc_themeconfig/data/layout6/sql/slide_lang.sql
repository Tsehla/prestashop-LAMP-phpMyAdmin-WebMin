INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('5','_ID_LANG_','New arrivals','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br /> odio. Praesent libero. Sed cursus ante dapibus dia</p>','for wormen’s','Purchase now','#','6e46b972a53dc316f4af6a9c724d001bcf2415cd_slider-6.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('10','_ID_LANG_','New arrivals','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit<br /> odio. Praesent libero. Sed cursus ante dapibus dia</p>','party dresses','Purchase now','#','29f8bc708c5880b8576f5d131753c961ac5bd28e_6-2.jpg');


