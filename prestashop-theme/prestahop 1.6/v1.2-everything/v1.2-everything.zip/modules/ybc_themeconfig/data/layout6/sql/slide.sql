INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('5','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('10','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('5','0','1','random','6%','10%','10%','type1','left','left','50%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('10','0','1','random','6%','10%','10%','type3','left','left','60%','','#');


