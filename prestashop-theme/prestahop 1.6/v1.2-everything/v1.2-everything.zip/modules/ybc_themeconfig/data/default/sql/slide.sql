INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('1','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('7','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('1','0','1','random','10%','10%','25%','type1','left','left','50%','c2_ls_5','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('7','0','1','random','11%','10%','1%','type2','right','center','45%','cl_white bt_white','#');


