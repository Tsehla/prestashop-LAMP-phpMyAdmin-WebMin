INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('2','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('8','1');
INSERT INTO `_DB_PREFIX_ybcnivoslider` VALUES('9','1');


INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('2','0','1','random','24%','10%','1%','type2','right','left','43%','','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('8','2','1','random','24%','5%','1%','type2','right','left','42%','text_black','#');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides` VALUES('9','1','1','random','22%','8%','1%','type3','left','left','42%','','#');


