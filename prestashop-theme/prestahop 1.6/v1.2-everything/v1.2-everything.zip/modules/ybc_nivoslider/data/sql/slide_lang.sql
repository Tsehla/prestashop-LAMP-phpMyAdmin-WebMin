INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('2','_ID_LANG_','New FAshion trends 2017','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer <br /> nec odio. Praesent libero. Sed cursus ante</p>','40% off all products','Shop now','#','c0973388feaaadbff3b39fd70c5fa2ec4619a331_slider1.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('8','_ID_LANG_','New Sport shoes','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer <br /> nec odio. Praesent libero. Sed cursus ante</p>','10% off all products','Shop now','#','572834c059b3c644925f4cdd440cad9096658baf_slider2.jpg');
INSERT INTO `_DB_PREFIX_ybcnivoslider_slides_lang` VALUES('9','_ID_LANG_','New Apple products','<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer<br /> nec odio. Praesent libero. Sed cursus ante</p>','10% off all products','Shop now','#','053c637009054df259a61ed8161fafd2f85db1d6_slider3.jpg');


