<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_homecategories}prestashop>homecat-grouped_40dec546414c1ebdfde8d9858f0938c3'] = 'כל המוצרים';
$_MODULE['<{ets_homecategories}prestashop>homecat-list_40dec546414c1ebdfde8d9858f0938c3'] = 'כל המוצרים';
