/**
 * 2007-2022 ETS-Soft
 *
 * NOTICE OF LICENSE
 *
 * This file is not open source! Each license that you purchased is only available for 1 wesite only.
 * If you want to use this file on more websites (or projects), you need to purchase additional licenses.
 * You are not allowed to redistribute, resell, lease, license, sub-license or offer our resources to any third party.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please contact us for extra customization service at an affordable price
 *
 *  @author ETS-Soft <etssoft.jsc@gmail.com>
 *  @copyright  2007-2022 ETS-Soft
 *  @license    Valid for 1 website (or project) for each purchase of license
 *  International Registered Trademark & Property of ETS-Soft
 */

import blockwishlistModule from 'blockwishlistModule';

const tabButtons = document.querySelectorAll('.btn-group button');
const refreshButton = document.querySelector('.js-refresh');
let isLoading = false;

tabButtons.forEach((button) => {
  button.addEventListener('click', () => {
    if (!button.classList.contains('active')) {
      tabButtons.forEach((elem) => {
        elem.classList.remove('active');
      });

      button.classList.add('active');

      const tabs = document.querySelectorAll('.wishlist-tab');

      tabs.forEach((tab) => {
        if (tab.classList.contains('active') && tab.dataset.tab !== button.dataset.tab) {
          tab.classList.remove('active');
        }

        if (tab.dataset.tab === button.dataset.tab) {
          tab.classList.add('active');
        }
      });
    }
  });
});

refreshButton.addEventListener('click', async () => {
  if (!isLoading) {
    isLoading = true;

    const cacheButton = refreshButton.innerHTML;

    refreshButton.innerHTML = '<i class="material-icons">hourglass_empty</i>';

    const response = await fetch(`${blockwishlistModule.resetCacheUrl}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json, text/javascript, */*; q=0.01',
      },
    });

    const {success} = await response.json();

    if (success) {
      location.reload();
    } else {
      isLoading = false;
      refreshButton.innerHTML = cacheButton;
    }
  }
});
